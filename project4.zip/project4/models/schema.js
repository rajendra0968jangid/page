const mongoose = require('mongoose');
const pageData = mongoose.Schema({
    title:String,
    desc:String,
})

module.exports=mongoose.model('pageData',pageData);