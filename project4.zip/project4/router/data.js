const router = require('express').Router();
const pageData = require('../models/schema');

router.get('/shows/:id',async(req,res)=>{
    const id = req.params.id;
    const data = await pageData.find(); 
    res.render('./html/data.ejs',{mess:id,student:data});
})

router.get('/update/:id',async(req,res)=>{
    const id = req.params.id;
    const data = await pageData.findById(id);
    res.render('./html/edit.ejs',{title:data.title,desc:data.desc});
})

router.post('/update/:id',async(req,res)=>{
    const id = req.params.id;
    const {title,desc} = req.body;
    const data = await pageData.findByIdAndUpdate(id,{title:title,desc:desc});
    res.redirect('/shows/"successfully updated"');
})

router.get('/delete/:id',async(req,res)=>{
    const id = req.params.id;
    await pageData.findByIdAndDelete(id,{});
    res.redirect('/shows/"successfully removed"');
})

module.exports=router;


