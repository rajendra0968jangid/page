const router = require('express').Router();
const  pageData = require('../models/schema');

router.get('/',(req,res)=>{
    res.render('./html/index.ejs');
})

router.post('/',(req,res)=>{
    const {title,desc} = req.body;
    const data = new pageData({title:title,desc:desc});
    data.save();
    res.redirect('/shows/"successfully inserted data"');
})

module.exports=router;